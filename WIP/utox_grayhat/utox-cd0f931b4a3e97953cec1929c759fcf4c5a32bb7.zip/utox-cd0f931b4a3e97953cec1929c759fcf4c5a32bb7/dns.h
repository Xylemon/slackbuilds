void dns_request(char_t *name, uint16_t length);
