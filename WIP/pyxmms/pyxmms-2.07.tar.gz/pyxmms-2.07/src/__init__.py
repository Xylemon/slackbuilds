# __init__.py --- Initialization file for the xmms package.
# Copyright (c) 2003 Florent Rougon
#
# This file is part of PyXMMS.
#
# PyXMMS is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 dated June, 1991.
#
# PyXMMS is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING. If not, write to the
# Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
# Boston, MA  02110-1301 USA.

"""Python interface to XMMS --- initialization of the xmms package.

This file contains initialization code for the xmms package.

"""

import sys

__all__ = ["common", "control", "config"]

# This brings us common.error, which is expected to be here
from common import *
# For backward compatibility
from control import *
