<?php

# Include all necessary support files...
include "vars.inc";
include "classes.inc";
if ($xc_mode=="ha1")
{
	include "../vars.inc";
	include "../funcs.inc";
}

if (isset($comm))
{
		if ($comm=="delete")
		{
			unlink($file);
		}
}

if ($xc_mode=="sa")
{
	# Begin the HTML page...
	echo "<HTML>\n";
	echo "<HEAD>\n";
	# Display the title...
	echo "<TITLE>".$title."</TITLE>\n";
	echo "</HEAD>\n";
	echo "<BODY BGCOLOR=000000 TEXT=00FF00 LINK=0000FF VLINK=0000FF>\n";
	
	# DISPLAY HEADING
	echo "<H1 ALIGN=CENTER>\n";
	echo $title."\n";
	echo "</H1>\n";
} elseif ($xc_mode=="ha1") {
	fy_starthtml("", $cookie_theme ,"../");
}

echo "<H3 ALIGN=CENTER>\n";

$a1="<FONT COLOR=000000>";
$a2="</FONT>";

if ($xc_mode=="sa") {echo "<HR>";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}
echo "PLAYLIST MANAGER<BR>\n";
if ($xc_mode=="sa") {echo "<HR>";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}

# DISPLAY ALL PLAYLISTS IN A FORM
exec("ls -1 --color=no ".$pl_path."/*.m3u | sort", $output4, $returnvalue4);
echo "<P>";
echo "Playlists:<BR>";
echo "<TABLE BORDER>";
echo "<TR BGCOLOR=FFFFFF><TH>$a1 Playlist $a2</TH><TH COLSPAN=3>$a1 Admin. $a2</TH></TR>";
for ($jr=0;$jr<count($output4);$jr++)
{
	echo "<TR BGCOLOR=FFFFFF>";
	$jtemp=ereg_replace("\[0m","",trim($output4[$jr]));
	echo "<TH ALIGN=LEFT>$a1";
	$pl=substr($jtemp,strrpos($jtemp,"/")+1,strlen(substr($jtemp,strrpos($jtemp,"/")))-5)."\n";
	echo $pl;
	echo "$a2</TH>";
	echo "<TH>$a1<A HREF=editlist.php?comm=load&file=".trim($output4[$jr]).">Edit$a2</A></TH>";
	echo "<TH>$a1<A HREF=index.php?comm=loadplaylist&playlist=".$pl.">Play$a2</A></TH>";
	echo "<TH>$a1<A HREF=listmanager.php?comm=delete&file=".trim($output4[$jr]).">Delete$a2</A></TH>";
	echo "</TR>";
}
echo "</TABLE>";
echo "<P>";
if ($xc_mode=="sa") {echo "<HR>";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}

# CREATE NEW PLAYLIST
echo "<FORM ACTION=editlist.php?comm=new METHOD=POST>\n";
echo "Create Playlist:<BR>";
echo "Playlist Name: ";
echo "<INPUT NAME=file SIZE=20 MAXLENGTH=50>";
echo " ";
echo "<INPUT TYPE=SUBMIT VALUE=Create New Playlist>\n";
echo "</FORM>\n";

echo "<P>";
if ($xc_mode=="sa") {echo "<HR>";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}
echo "<A HREF=index.php>Return to Main Controls</A>";
	
if ($xc_mode=="sa") {echo "<HR>";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}

if ($xc_mode=="sa")
{
	echo "<P ALIGN=CENTER><A HREF=".$xc_www.">XMMS-Control $version</A> By <A HREF=mailto:".$jemail.">Joe Thielen</A></P>";
	echo "</BODY></HTML>\n";
} elseif ($xc_mode=="ha1") {
	fy_endhtml("");
}

?>
