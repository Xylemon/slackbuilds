<?php

# Include all necessary support files...
include "vars.inc";
include "classes.inc";
if ($xc_mode=="ha1")
{
	include "../vars.inc";
	include "../funcs.inc";
}

if ($xc_mode=="sa")
{
	# Begin the HTML page...
	echo "<HTML>\n";
	echo "<HEAD>\n";
	# Display the title...
	echo "<TITLE>".$title."</TITLE>\n";
	echo "</HEAD>\n";
	echo "<BODY BGCOLOR=000000 TEXT=00FF00 LINK=0000FF VLINK=0000FF>\n";

	# DISPLAY HEADING
	echo "<H1 ALIGN=CENTER>\n";
	echo $title."\n";
	echo "</H1>\n";
	
	echo "<HR>\n";
} elseif ($xc_mode=="ha1") {
	fy_starthtml($meta, $cookie_theme, "../");
}

echo "<H3 ALIGN=CENTER>\n";

echo "<P>";
echo "Current Directory: ".$dir;
echo "<P>";

# ---Start Form---
echo "<FORM ACTION=editlist.php?comm=addfile&file=$file METHOD=post>";
#exec("ls -l -c1 --color=no ".$dir."/*.mp3 | sort", $output4, $returnvalue4);
exec("ls -1 --color=no ".$dir."/*.mp3 | sort", $output4, $returnvalue4);

echo "<SELECT NAME=addfiles[] SIZE=10 MULTIPLE>";
for ($jr=0;$jr<count($output4);$jr++)
{
	$jtemp=ereg_replace("\[0m","",trim($output4[$jr]));
	$jtemp=ereg_replace("\\\\","",$jtemp);
	echo "<OPTION VALUE=\"";
	echo $jtemp;
	echo "\">";
	echo substr($jtemp,strrpos($jtemp,"/")+1,strlen(substr($jtemp,strrpos($jtemp,"/")))-1)."\n";
}
echo "</SELECT>";

echo "<BR>";
echo "<P>";

# ---Submit & Reset---
echo "<INPUT TYPE=SUBMIT VALUE=\"Add Files\">";
echo " ";
echo "<INPUT TYPE=RESET VALUE=Clear>";
# ---End Form---
echo "</FORM>";
echo "<P>";

if ($xc_mode=="sa") {echo "<HR>\n";} elseif ($xc_mode=="ha1") {fy_showhr($cookie_theme, "../");}

echo "<H3 ALIGN=CENTER>\n";

echo "<P>";
echo "Change Directory";
echo "<P>";

# ---Start Form---

echo "<FORM ACTION=filechooser.php?file=$file METHOD=post>";
echo "<SELECT NAME=dir SIZE=10>";
echo "<OPTION VALUE=\"".substr($dir, 0, strrpos($dir,"/"))."\">MOVE UP";
$dircnt=0;
$dirH=opendir($dir); 
while (false!==($cfile = readdir($dirH)))
{ 
	if (($cfile != "." && $cfile != "..") AND is_dir($dir."/".trim($cfile)))
	#{echo "<OPTION>".$dir."/".$cfile."\n";}
	{
		# Let's put each directory into an array so we can sort it later...
		$dirarr[$dircnt]=$dir."/".$cfile;
		$dircnt++;
	}
}

# Only sort the array if there is more than one element in it... 
# this avoids errors with the sort() function if there are less
# than two elements...
if (count($dirarr)>1)
{sort($dirarr);}

# Let's cycle through the array and display each element..
for ($jr=0;$jr<count($dirarr);$jr++)
{echo "<OPTION>".$dirarr[$jr]."\n";}

echo "</SELECT>";
closedir($dirH);

echo "<BR>";
echo "<P>";

# ---Submit & Reset---
echo "<INPUT TYPE=SUBMIT VALUE=\"Change Directory\">";
# ---End Form---
echo "</FORM>";

echo "<P>";
echo "<A HREF=editlist.php?file=$file>Return to List Editor</A>";
echo "<P>";
	
if ($xc_mode=="sa")
{
	echo "<HR>\n";
	echo "<P ALIGN=CENTER><A HREF=".$xc_www.">XMMS-Control $version</A> By <A HREF=mailto:".$jemail.">Joe Thielen</A></P>";
	echo "</BODY></HTML>\n";
} elseif ($xc_mode=="ha1") {
	fy_endhtml();
}

?>
