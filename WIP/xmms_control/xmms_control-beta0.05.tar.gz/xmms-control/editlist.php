<?php

# Joe Thielen's XMMS-CONTROL - List Editor

# Include all necessary support files...
include "vars.inc";
include "classes.inc";
if ($xc_mode=="ha1")
{
	include "../vars.inc";
	include "../funcs.inc";
}

if ($file=="")
{
	# Begin the HTML page...
	echo "<HTML>\n";
	echo "<HEAD>\n";
	# Display the title...
	echo "<TITLE>".$title."</TITLE>\n";
	echo "</HEAD>\n";
	echo "<BODY BGCOLOR=000000 TEXT=00FF00 LINK=0000FF VLINK=0000FF>\n";

	# DISPLAY HEADING
	echo "<H1 ALIGN=CENTER>\n";
	echo $title."\n";
	echo "</H1>\n";
	echo "<HR>\n";

	echo "<H3 ALIGN=CENTER>\n";
	echo "<P>";
	echo "ERROR!<BR>";
	echo "No filename was specified!<BR>";
	echo "<P>";
	echo "<A HREF=index.php>Back</A>";
	echo "<P>";
	
	echo "<HR>\n";
	echo "<P ALIGN=CENTER><A HREF=".$xc_www.">XMMS-Control $version</A> By <A HREF=mailto:".$jemail.">Joe Thielen</A></P>";
	echo "</H3>";
	
	echo "</BODY></HTML>\n";
	exit;
	exit;
}

# If there was a command, execute it!
if (isset($comm))
{
	$nowrite=0;

	if ($comm=="new")
	{
		$file=$pl_path."/".$file.".m3u.xctemp";
	}

	if ($comm=="load")
	{
			copy($file, $file.".xctemp");
			$file=$file.".xctemp";
			$nowrite=1;
	}

	if ($comm=="cancel")
	{
		$meta="<META HTTP-EQUIV=REFRESH CONTENT=0;URL=listmanager.php>";
		unlink($file);
		$nowrite=1;
	}

	if ($comm=="remove" OR $comm=="moveup" OR $comm=="movedown" OR $comm=="save" OR $comm=="addfile")
	{
		# Open the file...
		$fileh=fopen($file,"r");

		$jt=0;
		$ef=0;
		while (!feof($fileh))
		{
			if ($jt==$jid AND $comm=="remove") {$ef=1;}
			if ($ef<>1)
			{$line2[$jt]=fgets($fileh, 4096);}
			else {$temp=fgets($fileh, 4096);}
			$ef=0;
			$jt++;
		}

		if ($comm=="moveup")
		{
				$temp=$line2[$jid];
				$line2[$jid]=$line2[($jid-1)];
				$line2[($jid-1)]=$temp;
		}

		if ($comm=="movedown")
		{
				$temp=$line2[$jid];
				$line2[$jid]=$line2[($jid+1)];
				$line2[($jid+1)]=$temp;
		}
		
		# Close the open file...
		fclose($fileh);
	}

	if ($comm=="addfile")
	{
			$jt=count($line2)-1;
			for ($jr=0;$jr<count($addfiles);$jr++)
			{
					$line2[$jt]=ereg_replace("\\\\","",$addfiles[$jr])."\n";
					$jt++;
			}
	}

	if ($comm=="save")
	{
		unlink($file);
		$file2=substr($file, 0, strlen($file)-7);
		$file=$file2;
		# Get the basic name of the playlist...
		$file3=substr($file,strrpos($file,"/")+1,strlen(substr($file,strrpos($file,"/")))-5)."\n";

		if ($id==0)
		{$meta="<META HTTP-EQUIV=REFRESH CONTENT=0;URL=listmanager.php>";}
		else {$meta="<META HTTP-EQUIV=REFRESH CONTENT=0;URL=index.php?comm=loadplaylist&playlist=$file3>";}
	}

	if ($nowrite==0)
	{
		# WRITE THE FILE!
		$fileh=fopen($file,"w");
		for ($jt=0;$jt<count($line2);$jt++)
		{fwrite($fileh, $line2[$jt]);}
		fclose($fileh);
	}
}

if ($xc_mode=="sa")
{
	# Begin the HTML page...
	echo "<HTML>\n";
	echo "<HEAD>\n";
	echo $meta;
	# Display the title...
	echo "<TITLE>".$title."</TITLE>\n";
	echo "</HEAD>\n";
	echo "<BODY BGCOLOR=000000 TEXT=00FF00 LINK=0000FF VLINK=0000FF>\n";

	# DISPLAY HEADING
	echo "<H1 ALIGN=CENTER>\n";
	echo $title."\n";
	echo "</H1>\n";
	echo "<HR>\n";
} elseif ($xc_mode=="ha1") {
	fy_starthtml($meta, $cookie_theme, "../");
}


echo "<H3 ALIGN=CENTER>\n";

if ($comm<>"cancel" AND $comm<>"save")
{
# Open the file...
$fileh=fopen($file,"r");

$jt=0;
while (!feof($fileh))
{
	$line[$jt]=fgets($fileh, 4096);
	$jt++;
}

# Close the open file...
fclose($fileh);

$a1="<FONT COLOR=000000>";
$a2="</FONT>";

echo "<TABLE BORDER ALIGN=CENTER>";
echo "<TR BGCOLOR=FFFFFF><TH>$a1 File<BR>Num $a2</TH><TH>$a1 File Name $a2</TH><TH>$a1 File<BR>Exists? $a2</TH><TH COLSPAN=3>$a1 Admin $a2</TH></TR>";

for ($jr=0;$jr<count($line)-1;$jr++)
{
		echo "<TR BGCOLOR=FFFFFF>";
		echo "<TH ALIGN=LEFT>$a1".$jr."$a2</TH>";
		echo "<TH ALIGN=LEFT>$a1".$line[$jr]."$a2</TH>";
		$temp=file_exists(trim($line[$jr]));
		if ($temp==1) {$temp="<FONT COLOR=000000>Yes</FONT>";} else {$temp="<FONT COLOR=FF0000>NO!</FONT>";}
		echo "<TH>$temp</TH>";
		echo "<TH>$a1<A HREF=editlist.php?file=$file&comm=remove&jid=".$jr.">Remove</A>$a2</TH>";
		if ($jr>0)
		{echo "<TH>$a1<A HREF=editlist.php?file=$file&comm=moveup&jid=".$jr.">Move Up</A>$a2</TH>";}
		else {echo "<TH>$a1"."Move Up"."$a2</TH>";}
		if ($jr<count($line)-2)
		{echo "<TH>$a1<A HREF=editlist.php?file=$file&comm=movedown&jid=".$jr.">Move Down</A>$a2</TH>";}
		else {echo "<TH>$a1"."Move Down"."$a2</TH>";}
		echo "</TR>";
}
echo "</TABLE>";

echo "<P>";
echo "<A HREF=filechooser.php?file=$file&dir=$mp_path>Add File</A>";
echo "<P>";
echo "<A HREF=editlist.php?comm=save&id=0&file=$file>Save Changes & Return to Playlist Manager</A>";
echo "<P>";
echo "<A HREF=editlist.php?comm=save&id=1&file=$file>Save Changes & Load this Playlist</A>";
echo "<P>";
echo "<A HREF=editlist.php?comm=cancel&file=$file>Cancel Changes</A>";
echo "<P>";

} else {
	echo "Plese Wait!<BR>Returning to Main Controls...";
	echo "<P>";
}

if ($xc_mode=="sa")
{
	echo "<HR>\n";
	echo "<P ALIGN=CENTER><A HREF=".$xc_www.">XMMS-Control $version</A> By <A HREF=mailto:".$jemail.">Joe Thielen</A></P>";
	echo "</BODY></HTML>\n";
} else {
	fy_endhtml();
}

?>
