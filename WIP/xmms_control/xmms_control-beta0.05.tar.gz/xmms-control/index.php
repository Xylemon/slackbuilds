<?php

# set for Stand-alone (s) or HA-Integrated (ha1)...
#$xc_mode="sa";
#$xc_mode="ha1";

# Include all necessary support files...
include "vars.inc";
include "classes.inc";
if ($xc_mode=="ha1")
{
	include "../vars.inc";
	include "../funcs.inc";
}

$script="index.php";

# Create a new Xmms_Control object...
$xmms_control_obj=new Xmms_Control;
$xmms_control_obj->init($xs_path);

function bc($cl, $rl) 
{
	if ($cl == $rl)
	{$ret="X";}
	else {$ret=chr(160);}

	return $ret;
}

if ($refresh=="auto")
{$meta="<META HTTP-EQUIV=REFRESH CONTENT=$refresh_rate;URL=".$script."?refresh=auto>";}

if ($xc_mode=="ha1")
{
	fy_starthtml($meta, $cookie_theme, "../");
} elseif ($xc_mode=="sa") {
	# Begin the HTML page...
	echo "<HTML>\n";
	echo "<HEAD>\n";
	# If refreshing is enabled, do it...
	if ($refresh=="auto")
	{echo $meta;}
	# Display the title...
	echo "<TITLE>".$title."</TITLE>\n";
	echo "</HEAD>\n";
	#echo "<BODY BGCOLOR=000000 TEXT=00FF00 LINK=0000FF VLINK=0000FF>\n";
	echo "<BODY BGCOLOR=".$normal_background." TEXT=".$normal_text." LINK=".$normal_link." VLINK=".$normal_link.">\n";
}

# Execute a command, if one was given...
if (isset($comm))
{
	$nosleep=0;

	# EXECUTE COMMAND
	if ($comm=="play") {$xmms_control_obj->play();}
	if ($comm=="stop") {$xmms_control_obj->stop();}
	if ($comm=="pause") {$xmms_control_obj->pause();}
	if ($comm=="forward") {$xmms_control_obj->forward();}
	if ($comm=="backward") {$xmms_control_obj->backward();}
	if ($comm=="clear") {$xmms_control_obj->playlist_clear();}
	if ($comm=="shuffle_on") {$xmms_control_obj->shuffle_on();$nosleep=1;}
	if ($comm=="shuffle_off") {$xmms_control_obj->shuffle_off();$nosleep=1;}
	if ($comm=="repeat_on") {$xmms_control_obj->repeat_on();$nosleep=1;}
	if ($comm=="repeat_off") {$xmms_control_obj->repeat_off();$nosleep=1;}
	if ($comm=="volume") {$xmms_control_obj->volume($vol);$nosleep=1;}
	if ($comm=="band") {$xmms_control_obj->band($bn,$bl);$nosleep=1;}
	if ($comm=="setband") {$xmms_control_obj->Setband($bl);$nosleep=1;}
	if ($comm=="jump")
	{
			$xmms_control_obj->jump($jumpto);
			sleep(2);
			if (substr($xmms_control_obj->getStatus(),0,7)=="Current")
			{
				$xmms_control_obj->play();
			}
	}
	if ($comm=="loadplaylist")
	{
		$xmms_control_obj->playlist_clear();
		$xmms_control_obj->playlist_load($pl_path."/".$playlist.".m3u");
		$xmms_control_obj->jump(1);
		if (STRTOLOWER($autoplay)=="enable")
		{sleep(1);$xmms_control_obj->play();}
	}

	if ($nosleep==0)
	{sleep(2);}
}

# GET CURRENT STATUS
$status=$xmms_control_obj->getStatus();

# GET THE CURRENT PLAYLIST...
$playlist=explode("#_#",$xmms_control_obj->getPlaylist());

# GET THE CURRENT SONG...
$songname=$xmms_control_obj->getSongName();

# GET CURRENT VOLUME
$volume=trim($xmms_control_obj->getVolume());

if ($xc_mode=="sa")
{
	# DISPLAY HEADING
	echo "<H1 ALIGN=CENTER>\n";
	echo $title."\n";
	echo "</H1>\n";
}

echo "<H3 ALIGN=CENTER>\n";

# DISPLAY STATUS
if ($xc_mode=="sa") {echo "<HR>\n";}
echo $status." (<A HREF=".$script."?refresh=$refresh>Refresh</A> | <A HREF=".$script."?refresh=auto>Auto</A> | <A HREF=".$script.">Stop</A>)\n";
echo "<BR>\n";

# DISPLAY STANDARD COMMANDS
echo "<A HREF=".$script."?refresh=$refresh&comm=backward>Prev</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=forward>Next</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=stop>Stop</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=pause>Pause</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=play>Play</A> | ";
echo "Random: ";
echo "<A HREF=".$script."?refresh=$refresh&comm=shuffle_on>On</A> ";
echo "<A HREF=".$script."?refresh=$refresh&comm=shuffle_off>Off</A>";
echo " | Repeat: ";
echo "<A HREF=".$script."?refresh=$refresh&comm=repeat_on>On</A> ";
echo "<A HREF=".$script."?refresh=$refresh&comm=repeat_off>Off</A>";
echo "<BR>\n";
echo "</H3>\n";

# DISPLAY VOLUME BAR
echo "<H4 ALIGN=CENTER>\n";
echo "Volume: <BR>\n | ";
for ($x=0;$x<105;$x=$x+5)
{
	if ($x==$volume) {echo "<B><I>".$x."%</I></B>";}
	else {echo "<A HREF=".$script."?refresh=$refresh&comm=volume&vol=".$x.">".$x."%</A>";}
	echo " |\n";
}
echo "</H4>\n";
echo "<H3 ALIGN=CENTER>\n";

# Disable EQ
if (STRTOUPPER($eq)=="ENABLE")
{
echo "<TABLE BORDER ALIGN=CENTER>";
echo "<TR><TH COLSPAN=12>XMMS-Control Equalizer!</TH></TR>";
echo "<TR>";
echo "<TH>".chr(160)."</TH>";
echo "<TH>60</TH>";
echo "<TH>170</TH>";
echo "<TH>310</TH>";
echo "<TH>600</TH>";
echo "<TH>1K</TH>";
echo "<TH>3K</TH>";
echo "<TH>6K</TH>";
echo "<TH>12K</TH>";
echo "<TH>14K</TH>";
echo "<TH>16K</TH>";
echo "<TH>-All-</TH>";
echo "</TR>";

$bt=$xmms_control_obj->getBand(0);
$b0=substr($bt[0],8,5);
$b1=substr($bt[1],8,5);
$b2=substr($bt[2],8,5);
$b3=substr($bt[3],8,5);
$b4=substr($bt[4],8,5);
$b5=substr($bt[5],8,5);
$b6=substr($bt[6],8,5);
$b7=substr($bt[7],8,5);
$b8=substr($bt[8],8,5);
$b9=substr($bt[9],8,5);

echo "<TR BGCOLOR=FF0000>";
echo "<TH>".$sf."+20db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=20>".bc($blp20,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=20>".bc($blp20,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=20>".bc($blp20,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=20>".bc($blp20,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=20>".bc($blp20,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=20>".bc($blp20,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=20>".bc($blp20,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=20>".bc($blp20,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=20>".bc($blp20,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=20>".bc($blp20,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=20>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=FF4400>";
echo "<TH>".$sf."+15db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=15>".bc($blp15,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=15>".bc($blp15,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=15>".bc($blp15,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=15>".bc($blp15,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=15>".bc($blp15,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=15>".bc($blp15,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=15>".bc($blp15,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=15>".bc($blp15,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=15>".bc($blp15,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=15>".bc($blp15,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=15>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=FF8800>";
echo "<TH>".$sf."+10db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=10>".bc($blp10,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=10>".bc($blp10,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=10>".bc($blp10,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=10>".bc($blp10,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=10>".bc($blp10,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=10>".bc($blp10,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=10>".bc($blp10,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=10>".bc($blp10,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=10>".bc($blp10,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=10>".bc($blp10,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=10>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=FFAA00>";
echo "<TH>".$sf."+5db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=5>".bc($blp5,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=5>".bc($blp5,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=5>".bc($blp5,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=5>".bc($blp5,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=5>".bc($blp5,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=5>".bc($blp5,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=5>".bc($blp5,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=5>".bc($blp5,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=5>".bc($blp5,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=5>".bc($blp5,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=5>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=FFFF00>";
echo "<TH>".$sf."+0db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=0>".bc($bl_0,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=0>".bc($bl_0,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=0>".bc($bl_0,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=0>".bc($bl_0,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=0>".bc($bl_0,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=0>".bc($bl_0,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=0>".bc($bl_0,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=0>".bc($bl_0,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=0>".bc($bl_0,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=0>".bc($bl_0,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=0>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=AAFF00>";
echo "<TH>".$sf."-5db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=-5>".bc($bln5,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=-5>".bc($bln5,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=-5>".bc($bln5,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=-5>".bc($bln5,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=-5>".bc($bln5,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=-5>".bc($bln5,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=-5>".bc($bln5,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=-5>".bc($bln5,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=-5>".bc($bln5,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=-5>".bc($bln5,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=-5>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=88FF00>";
echo "<TH>".$sf."-10db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=-10>".bc($bln10,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=-10>".bc($bln10,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=-10>".bc($bln10,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=-10>".bc($bln10,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=-10>".bc($bln10,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=-10>".bc($bln10,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=-10>".bc($bln10,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=-10>".bc($bln10,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=-10>".bc($bln10,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=-10>".bc($bln10,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=-10>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=44FF00>";
echo "<TH>".$sf."-15db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=-15>".bc($bln15,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=-15>".bc($bln15,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=-15>".bc($bln15,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=-15>".bc($bln15,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=-15>".bc($bln15,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=-15>".bc($bln15,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=-15>".bc($bln15,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=-15>".bc($bln15,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=-15>".bc($bln15,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=-15>".bc($bln15,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=-15>Set All</A></TH>";
echo "</TR>";
echo "<TR BGCOLOR=00FF00>";
echo "<TH>".$sf."-20db".$ef."</TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=0&bl=-20>".bc($bln20,$b0)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=1&bl=-20>".bc($bln20,$b1)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=2&bl=-20>".bc($bln20,$b2)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=3&bl=-20>".bc($bln20,$b3)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=4&bl=-20>".bc($bln20,$b4)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=5&bl=-20>".bc($bln20,$b5)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=6&bl=-20>".bc($bln20,$b6)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=7&bl=-20>".bc($bln20,$b7)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=8&bl=-20>".bc($bln20,$b8)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=band&bn=9&bl=-20>".bc($bln20,$b9)."</A></TH>";
echo "<TH><A HREF=".$script."?refresh=$refresh&comm=setband&bl=-20>Set All</A></TH>";
echo "</TR>";
echo "</TABLE>";
}

if ($xc_mode=="sa") {echo "<HR>\n";} else {fy_showhr($cookie_theme, "../");}

# DISPLAY CURRENT PLAYLIST IN A FORM
echo "Current Playlist:<BR>\n";
echo "<FORM ACTION=".$script."?refresh=$refresh&comm=jump METHOD=POST>\n";
echo "<SELECT SIZE=10 NAME=jumpto>\n";
for ($jr=0;$jr<count($playlist);$jr++)
{
	# If this is the current song, make it selected...
	if (substr($playlist[$jr],strpos($playlist[$jr]," ")+1, strlen($playlist[$jr])-strpos($playlist[$jr]," "))==trim($songname))
	{echo "<OPTION SELECTED VALUE=".($jr+1).">".$playlist[$jr]."\n";}
	else {echo "<OPTION VALUE=".($jr+1).">".$playlist[$jr]."\n";}
}
echo "</SELECT><BR>\n";
echo "<INPUT TYPE=SUBMIT VALUE=Play>\n";
echo "</FORM>\n";

# DISPLAY 'CLEAR PLAYLIST' BUTTON
echo "<FORM ACTION=".$script."?comm=clear METHOD=POST>\n";
echo "<INPUT TYPE=SUBMIT VALUE=\"Clear Playlist\">\n";
echo "</FORM>\n";

if ($xc_mode=="sa") {echo "<HR>\n";} else {fy_showhr($cookie_theme, "../");}

# DISPLAY ALL PLAYLISTS IN A FORM
exec("ls -1 --color=no ".$pl_path."/*.m3u | sort", $output4, $returnvalue4);
echo "Other Playlists:<BR>\n";
echo "<FORM ACTION=".$script."?comm=loadplaylist METHOD=POST>\n";
echo "<SELECT SIZE=5 NAME=playlist>\n";
for ($jr=0;$jr<count($output4);$jr++)
{
	$jtemp=ereg_replace("\[0m","",trim($output4[$jr]));
	echo "<OPTION>".substr($jtemp,strrpos($jtemp,"/")+1,strlen(substr($jtemp,strrpos($jtemp,"/")))-5)."\n";
}
echo "</SELECT><BR>\n";
echo "<INPUT TYPE=SUBMIT VALUE=\"Load Playlist\">\n";
echo "</FORM>\n";
echo "<BR>";
if (STRTOLOWER($listmanager)=="enable")
{echo "<A HREF=listmanager.php>Playlist Manager</A>";}
	
if ($xc_mode=="sa") {
	echo "<HR>\n";
	echo "<P ALIGN=CENTER><A HREF=".$xc_www.">XMMS-Control $version</A> By <A HREF=mailto:".$jemail.">Joe Thielen</A></P>";
	echo "</BODY></HTML>\n";
} else {
	fy_endhtml();
}

?>
