<?php

# Interface For PDAs

# Include all necessary support files...
include "vars.inc";
include "classes.inc";

$script="index_pda.php";

# Create a new Xmms_Control object...
$xmms_control_obj=new Xmms_Control;
$xmms_control_obj->init($xs_path);

# Begin the HTML page...
echo "<HTML>\n";
echo "<HEAD>\n";
# If refreshing is enabled, do it...
if ($refresh=="auto")
{echo "<META HTTP-EQUIV=REFRESH CONTENT=$refresh_rate;URL=".$script."?refresh=auto>\n";}
# Display the title...
echo "<TITLE>".$title."</TITLE>\n";
echo "</HEAD>\n";
echo "<BODY BGCOLOR=".$pda_background." TEXT=".$pda_text." LINK=".$pda_link." VLINK=".$pda_link.">\n";

# Execute a command, if one was given...
if (isset($comm))
{
	$nosleep=0;

	# EXECUTE COMMAND
	if ($comm=="play") {$xmms_control_obj->play();}
	if ($comm=="stop") {$xmms_control_obj->stop();}
	if ($comm=="pause") {$xmms_control_obj->pause();}
	if ($comm=="forward") {$xmms_control_obj->forward();}
	if ($comm=="backward") {$xmms_control_obj->backward();}
	if ($comm=="clear") {$xmms_control_obj->playlist_clear();}
	if ($comm=="shuffle_on") {$xmms_control_obj->shuffle_on();$nosleep=1;}
	if ($comm=="shuffle_off") {$xmms_control_obj->shuffle_off();$nosleep=1;}
	if ($comm=="repeat_on") {$xmms_control_obj->repeat_on();$nosleep=1;}
	if ($comm=="repeat_off") {$xmms_control_obj->repeat_off();$nosleep=1;}
	if ($comm=="volume") {$xmms_control_obj->volume($vol);$nosleep=1;}
	if ($comm=="jump")
	{
			$xmms_control_obj->jump($jumpto);
			sleep(2);
			if (substr($xmms_control_obj->getStatus(),0,7)=="Current")
			{
				$xmms_control_obj->play();
			}
	}
	if ($comm=="loadplaylist")
	{
		$xmms_control_obj->playlist_clear();
		$xmms_control_obj->playlist_load($pl_path."/".$playlist.".m3u");
		$xmms_control_obj->jump(1);
		if (STRTOLOWER($autoplay)=="enable")
		{sleep(1);$xmms_control_obj->play();}
	}

	if ($nosleep==0)
	{sleep(2);}
}

# GET CURRENT STATUS
$status=$xmms_control_obj->getStatus();

# GET THE CURRENT PLAYLIST...
$playlist=explode("#_#",$xmms_control_obj->getPlaylist());

# GET THE CURRENT SONG...
$songname=$xmms_control_obj->getSongName();

# GET CURRENT VOLUME
$volume=trim($xmms_control_obj->getVolume());

# DISPLAY HEADING
echo "<B>";
echo $title."\n";

# DISPLAY STATUS
echo "<HR>\n";
echo $status."<BR>\n";
echo "Status: <A HREF=".$script.">Refresh</A> | <A HREF=".$script."?refresh=auto>Auto</A> | <A HREF=".$script.">Stop</A>\n";
echo "<BR>\n";

# DISPLAY STANDARD COMMANDS
echo "<A HREF=".$script."?refresh=$refresh&comm=backward>Prev</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=forward>Next</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=stop>Stop</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=pause>Pause</A> | ";
echo "<A HREF=".$script."?refresh=$refresh&comm=play>Play</A>\n";
echo "<BR>";
echo "Random: ";
echo "<A HREF=".$script."?refresh=$refresh&comm=shuffle_on>On</A> ";
echo "<A HREF=".$script."?refresh=$refresh&comm=shuffle_off>Off</A>";
echo " | Repeat: ";
echo "<A HREF=".$script."?refresh=$refresh&comm=repeat_on>On</A> ";
echo "<A HREF=".$script."?refresh=$refresh&comm=repeat_off>Off</A>";
echo "<BR>\n";

# DISPLAY VOLUME BAR
echo "Volume: <BR>\n | ";
for ($x=0;$x<105;$x=$x+5)
{
	if ($x==$volume) {echo "<B><I>".$x."%</I></B>";}
	else {echo "<A HREF=".$script."?refresh=$refresh&comm=volume&vol=".$x.">".$x."%</A>";}
	echo " |\n";
}

echo "<HR>\n";

# DISPLAY CURRENT PLAYLIST IN A FORM
echo "Current Playlist:<BR>\n";
echo "<FORM ACTION=".$script."?refresh=$refresh&comm=jump METHOD=POST>\n";
echo "<SELECT SIZE=10 NAME=jumpto>\n";
for ($jr=0;$jr<count($playlist);$jr++)
{
	# If this is the current song, make it selected...
	if (substr($playlist[$jr],strpos($playlist[$jr]," ")+1, strlen($playlist[$jr])-strpos($playlist[$jr]," "))==trim($songname))
	{echo "<OPTION SELECTED VALUE=".($jr+1).">".$playlist[$jr]."\n";}
	else {echo "<OPTION VALUE=".($jr+1).">".$playlist[$jr]."\n";}
}
echo "</SELECT><BR>\n";
echo "<INPUT TYPE=SUBMIT VALUE=Play>\n";
echo "</FORM>\n";

# DISPLAY 'CLEAR PLAYLIST' BUTTON
echo "<FORM ACTION=".$script."?comm=clear METHOD=POST>\n";
echo "<INPUT TYPE=SUBMIT VALUE=\"Clear Playlist\">\n";
echo "</FORM>\n";

echo "<HR>\n";

# DISPLAY ALL PLAYLISTS IN A FORM
exec("ls -l -c1 --color=no ".$pl_path."/*.m3u | sort", $output4, $returnvalue4);
echo "Other Playlists:<BR>\n";
echo "<FORM ACTION=".$script."?comm=loadplaylist METHOD=POST>\n";
echo "<SELECT SIZE=5 NAME=playlist>\n";
for ($jr=0;$jr<count($output4);$jr++)
{
	$jtemp=ereg_replace("\[0m","",trim($output4[$jr]));
	echo "<OPTION>".substr($jtemp,strrpos($jtemp,"/")+1,strlen(substr($jtemp,strrpos($jtemp,"/")))-5)."\n";
}
echo "</SELECT><BR>\n";
echo "<INPUT TYPE=SUBMIT VALUE=\"Load Playlist\">\n";
echo "</FORM>\n";

#if (STRTOLOWER($listmanager)=="enable")
#{echo "<A HREF=listmanager.php>Playlist Manager</A>";}
	
echo "<HR>\n";
echo "<A HREF=".$xc_www.">XMMS-Control $version</A><BR>\n";
echo "By <A HREF=mailto:".$jemail.">Joe Thielen</A><BR>\n";

echo "</BODY></HTML>\n";

?>
