<?php

# HOOKS SCRIPT
# Implements the XMMS-Control API
#
# ----- ARGUMENTS -----
# $backurl: The URL to redirect back to
# $backurlpause: The amount of time (in seconds) to pause before
#                redirecting back to backurl. (0 if none)
# $comm: The function to perform
# $comm2: The function modifier.  For instance, if the $comm is 'volume', 
#         then $comm2 should indicate the volume (0-100).
# $spash: Indicates if a splash screen is desired (X for yes)
# ---------------------

# Include all necessary support files...
include "vars.inc";
include "classes.inc";

$script="hooks.php";

# ----- CLEAN ARGUMENTS -----

# Let's make sure the backurl pause is valid.  If not, default to 0.
if ($backurlpause < 1) {$backurlpause=0;}

# Let's decode our $backurl... Turn (~) into (?), and (`) into (&)...
$backurl=ereg_replace("\~", "?", $backurl);
$backurl=ereg_replace("\`", "&", $backurl);

if (STRTOUPPER($splash)=="X")
{$splash="X";}
else {$splash="";}

# ---------------------------

# Create a new Xmms_Control object...
$xmms_control_obj=new Xmms_Control;
$xmms_control_obj->init($xs_path);

# Execute a command, if one was given...
if (isset($comm))
{
	$comm=STRTOLOWER($comm);

	$nosleep=0;

	# EXECUTE COMMAND
	if ($comm=="play") {$xmms_control_obj->play();}
	if ($comm=="stop") {$xmms_control_obj->stop();}
	if ($comm=="pause") {$xmms_control_obj->pause();}
	if ($comm=="forward" OR $comm=="next") {$xmms_control_obj->forward();}
	if ($comm=="backward" OR $comm=="prev" OR $comm=="previous") {$xmms_control_obj->backward();}
	if ($comm=="clear") {$xmms_control_obj->playlist_clear();}
	if ($comm=="shuffle_on") {$xmms_control_obj->shuffle_on();$nosleep=1;}
	if ($comm=="shuffle_off") {$xmms_control_obj->shuffle_off();$nosleep=1;}
	if ($comm=="repeat_on") {$xmms_control_obj->repeat_on();$nosleep=1;}
	if ($comm=="repeat_off") {$xmms_control_obj->repeat_off();$nosleep=1;}
	if ($comm=="volume") {$xmms_control_obj->volume($comm2);$nosleep=1;}
	if ($comm=="jump")
	{
			$xmms_control_obj->jump($comm2);
			sleep(2);
			if (substr($xmms_control_obj->getStatus(),0,7)=="Current")
			{
				$xmms_control_obj->play();
			}
	}
	if ($comm=="loadplaylist")
	{
		$xmms_control_obj->playlist_clear();
		$xmms_control_obj->playlist_load($pl_path."/".$comm2.".m3u");
		$xmms_control_obj->jump(1);
		if (STRTOLOWER($autoplay)=="enable")
		{sleep(1);$xmms_control_obj->play();}
	}

	#if ($nosleep==0)
	#{sleep(2);}
}

# If a splash screen is called for, do it!  Otherwise, just redirect...
echo "<HTML>\n";
echo "<HEAD>\n";
if ($splash=="X")
{echo "<TITLE>".$title."</TITLE>\n";}
echo "<META HTTP-EQUIV=REFRESH CONTENT=".$backurlpause.";URL=".$backurl.">\n";
echo "</HEAD>\n";
echo "<BODY>\n";

if ($splash=="X")
{
echo $title."<BR><P>\n";
echo "Executed command \"<I>".$comm;
if ($comm2 <> "") {echo "-".$comm2;}
echo "</I>\".<BR>\n";
echo "Returning to <A HREF=\"".$backurl."\">".$backurl."</A> in ".$backurlpause." seconds.<BR>\n";

}

echo "</BODY>\n";
echo "</HTML>\n";

?>
