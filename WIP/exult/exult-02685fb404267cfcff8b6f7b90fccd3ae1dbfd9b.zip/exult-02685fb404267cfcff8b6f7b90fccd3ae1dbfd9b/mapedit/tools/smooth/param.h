void show_help(char *prog_name);
int is_switch(char *val);
int read_param(int argc, char **argv);
