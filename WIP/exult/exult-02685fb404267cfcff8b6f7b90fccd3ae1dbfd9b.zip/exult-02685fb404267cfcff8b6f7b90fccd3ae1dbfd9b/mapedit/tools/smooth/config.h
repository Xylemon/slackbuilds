int close_config(FILE *f);
FILE *open_config(char *configfile);
int read_config(FILE *f);
