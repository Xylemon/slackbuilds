int main(int argc, char **argv);
Uint32 getpixel(SDL_Surface *surface, int x, int y);
