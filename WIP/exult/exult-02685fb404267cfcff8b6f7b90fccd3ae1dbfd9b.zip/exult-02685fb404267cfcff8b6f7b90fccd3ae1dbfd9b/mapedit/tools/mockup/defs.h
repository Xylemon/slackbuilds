typedef char chunk[2];
typedef char u7map[36864 * 2]; // 192*192 chunk, a chunk is 2 chars long
#define MAX_COLOURS 255
