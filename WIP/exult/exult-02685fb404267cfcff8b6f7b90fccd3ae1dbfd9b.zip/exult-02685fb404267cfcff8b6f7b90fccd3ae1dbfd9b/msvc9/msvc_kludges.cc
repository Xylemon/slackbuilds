// Precompiled header
#include "msvc_kludges.h"
