/*

    WMLOG by Tom Pycke <Tom.Pycke@advalvas.be>

    (C) 2000

    based on wmint

*/


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include "../wmgeneral/wmgeneral.h"
#include "../wmgeneral/misc.h"
#include "wmlog.h"
#include "wmlog-master.xpm"
#include "wmlog-mask.xbm"

#define min(x, y)   ((x)<(y))?x:y
char	*ProgName;

FILE *file1;   // /var/log/messages
FILE *file2;   // /var/log/warn
FILE *file3;   // ~/.X.err
char filename1[]=file1str;//"/var/log/messages";
char filename2[]=file2str;//"/var/log/warn";
char filename3[]=file3str;//"~/.X.err";
char xerr[100]; //see below


char newstr[256];
char labels[] = {   's', 'u', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\0',
	    'l', 'o', 'g', 'i', 'n', ' ', ' ', ' ', ' ', '\0',
	    't', 'f', 't', 'p', ' ', ' ', ' ', ' ', ' ', '\0',
	    'x', 'w', 'i', 'n', 'd', 'o', 'w', ' ', ' ', '\0',
	    'm', 'a', 'i', 'l', ' ', ' ', ' ', ' ', ' ', '\0',
	    'k', 'e', 'r', 'n', 'e', 'l', ' ', ' ', ' ', '\0',
	    'r', 'o', 'o', 't', 'l', 'o', 'g', 'i', 'n', '\0',
	    'o', 't', 'h', 'e', 'r', ' ', ' ', ' ', ' ', '\0',
	};
int counters[8]={0,0,0,0,0,0,0,0};
int logged[8]={0,0,0,0,0,0,0,0};
int maincounter = 0;
int scroll=10;
int blink=5;
int scrollit=1;
int taillines=4;
void checkout(char *thestr);
void BlitString(char *name, int x, int y);
void BlitNum(int num, int x, int y);
void DisplayLabel(char *label);
void DisplayScroll (char *label, int position);
void wmlog_routine(int, char **);

int getint (char *arg)
{
    int i;
    i=atoi (arg+2);
    if (i==0)
	i=atoi (arg+3);
    return i;
}

void main(int argc, char *argv[]) 
{

    int i;
    /* Parse Command Line */
    printf ("wmlog v0.2 (C) 2000 by Tom Pycke <Tom.Pycke@advalvas.be>\n");
    
    for (i=1; i<argc; i++)
    {
    char *arg = argv[i];

    if (argv[i][0]=='-')
    {
	switch (argv[i][1])
	{
	case 'd' :
	    if (strcmp(arg+1, "display"))
	    {
	    exit(1);
	    }
	    break;
	case 'v' :
	    printf ("Version 0.1\n");
	    exit(0);
	    break;
	case 's' :
	    scroll = getint (arg);//atoi (arg+2);
	    break;
	case 'l' :
	    taillines = getint(arg);//atoi (arg+2);
	    break;
	case 'b' :
	    blink = getint (arg);//atoi (arg+2);
	    break;
	case 'n' :
	    scrollit = 0;
	    break;
	default:
	    printf ("wmlog [options]\n"
		"    -v         print version\n"
		"    -s[1-10]   change scroll speed (default: 10)\n"
		"    -b[1-xx]   change red-led on (time in sec)\n"
		"    -l[1-xx]   number of lines the log has to print\n"
		"    -n         no scrolling\n"
		);
	    exit(0);
	    break;
	}
    }
    }
    blink *= 10;
    wmlog_routine(argc, argv);
}

int readline (char *string, FILE *file)
{
    if (fgets (string, 253, file) == NULL)  /* EOF or Error */
	return 1;
    if (string[strlen (string) - 1] == '\n')
	string[strlen (string) - 1] = '\0'; /* erase newline */
    else
    {
	ungetc (string[strlen (string) - 1], file);
	string[strlen (string) - 1] = '\0';
    }
    return 0;
}

void update ()
{
    if (readline (newstr, file1) == 0)
    {
	//  printf ("%s\n", newstr);
	maincounter = blink;
	checkout(newstr);
	for (;readline (newstr, file1)==0;)
	    checkout(newstr);
    }	
    if (readline (newstr, file2) == 0)
    {
	//  printf ("%s\n", newstr);
	maincounter = blink;
	checkout(newstr);
	for (;readline (newstr, file2)==0;)
	    checkout (newstr);
    }	
    if (readline (newstr, file3) == 0)
    {
    //	printf ("%s\n", newstr);
	copyXPMArea(87, 66, 4, 4, 5+3*7, 5);
	if (logged[3]<100)
	    logged[3]++;
	counters[3]=blink;
	maincounter = blink;
	for (;readline (newstr, file3)==0;)
	    logged[3]++;
    //  checkout(newstr);
    }	
}


FILE * openlog2 (char *file)
{
    FILE *f = fopen (file, "r");
    char dummy[256];
    struct stat statbuf;
    off_t size;
    if (f == NULL)
	return NULL;
    stat (file, &statbuf);
    size = statbuf.st_size;
    fseek (f, -1, SEEK_END);
    readline (dummy, f);
    return f;
}


void clr_led (int i)
{
    copyXPMArea(81, 66, 4, 4,  5+i*7,  5);
}

int search_line (char *line, char *str)
{
    int count, count2;
//  printf ("\n%s <-> %s", line, str);
    for (count=0; line[count]!='\0';count++)
    {
	if (line[count]==str[0])
	    for (count2=1; line[count2]!='\0'; count2++)
	    {   //printf ("%c:%c ", str[count2], line[count2+count]);
		if (str[count2] == '\0')
		    return 1;
		if (line[count2+count]!=str[count2])
		{   count++;
		    break;
		}   
	    }   
    }	    
    return 0;
}

void checkout(char *thestr)
{
    char failed_su[10], wrong_login[17], tftp[26], sendmail[9], kernel[7];
    char su_root[14], root_login[11];
    
    sprintf (failed_su, "FAILED SU");
    sprintf (wrong_login, "invalid password");
    sprintf (tftp, "tftpd");
    sprintf (sendmail, "mail");
    sprintf (kernel, "kernel");
    sprintf (su_root, "su: (to root)");
    sprintf (root_login, "ROOT LOGIN");
    
    if (search_line (thestr, failed_su) == 1)
    {
	copyXPMArea(87, 66, 4, 4, (5), 5);
	if (logged[0]<100)
	    logged[0]++;
	    counters[0]=blink;
    }
    else if (search_line (thestr, wrong_login) == 1)
    {
	copyXPMArea(87, 66, 4, 4, 12, 5);
	if (logged[1]<100)
	    logged[1]++;
	counters[1]=blink;
    }
    else if (search_line (thestr, tftp) == 1)
    {
	copyXPMArea(87, 66, 4, 4, 19, 5);
	if (logged[2]<100)
	    logged[2]++;
	counters[2]=blink;
    }
    else if (search_line (thestr, sendmail) == 1)
    {
	copyXPMArea(87, 66, 4, 4, 5+4*7, 5);
	if (logged[4]<100)
	    logged[4]++;
	counters[4]=blink;
    }
    else if (search_line (thestr, kernel) == 1)
    {
	copyXPMArea(87, 66, 4, 4, 5+5*7, 5);
	if (logged[5]<100)
	    logged[5]++;
	counters[5]=blink;
    }
    else if (search_line (thestr, su_root) == 1 || search_line (thestr, root_login) ==1)
    {
	copyXPMArea(87, 66, 4, 4, 5+6*7, 5);
	if (logged[6]<100)
	    logged[6]++;
	counters[6]=blink;
    }
    else
    {
	copyXPMArea(87, 66, 4, 4, 5+7*7, 5);
	if (logged[7]<100)
	    logged[7]++;
	counters[7]=blink;
    }
    
}

void wmlog_routine(int argc, char **argv)
{
    XEvent Event;
    int i, but_stat = -1;
    int index = 0;
    int pos=9;
    char exec[150];

    sprintf (xerr, "%s/%s", getenv ("HOME"), filename3);
    if ((file1 = openlog2 (filename1)) == NULL)
    {
	printf ("Can't open %s\n", filename1);
	exit (1);
    }	
    if ((file2 = openlog2 (filename2)) == NULL)
    {
	printf ("Can't open %s\n", filename2);
	exit (1);
    }	
    if ((file3 = openlog2 (xerr))==NULL)
    {
	printf ("Can't open ~/.X.err\n");
	exit (1);
    }	
    
    sprintf (newstr, "WMLOG by Tom Pycke");

    openXwindow(argc, argv, wmlog_master_xpm, bitmap_bits, bitmap_width, bitmap_height);

    // Display LEDs
    copyXPMArea(81, 66, 4, 4,  5,  5);
    copyXPMArea(81, 66, 4, 4, 12,  5);
    copyXPMArea(81, 66, 4, 4, 19,  5);
    copyXPMArea(81, 66, 4, 4, 26,  5);
    copyXPMArea(81, 66, 4, 4, 33,  5);
    copyXPMArea(81, 66, 4, 4, 40,  5);
    copyXPMArea(81, 66, 4, 4, 47,  5);
    copyXPMArea(81, 66, 4, 4, 54,  5);

    // Add buttons on LEDs
    AddMouseRegion( 0,	5,  5, 10, 10);
    AddMouseRegion( 1, 12,  5, 17, 10);
    AddMouseRegion( 2, 19,  5, 24, 10);
    AddMouseRegion( 3, 26,  5, 31, 10);
    AddMouseRegion( 4, 33,  5, 38, 10);
    AddMouseRegion( 5, 40,  5, 45, 10);
    AddMouseRegion( 6, 47,  5, 52, 10);
    AddMouseRegion( 7, 54,  5, 59, 10);
    AddMouseRegion( 8, 5, 21, 42, 30);
    AddMouseRegion( 9, 5, 49, 59, 59);

    RedrawWindow();

    BlitNum (0, 52, 21);
    BlitString(labels, 5,35);
    while (1)
    {
	RedrawWindow();
    
	// X Events
	while (XPending(display))
	{
	    XNextEvent(display, &Event);
	    switch (Event.type)
	    {
		case Expose:
		    RedrawWindow();
		    break;
		case DestroyNotify:
		    XCloseDisplay(display);
		    exit(0);
		    break;
		case ButtonPress:
		    i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);
		    but_stat = i;
		    break;
		case ButtonRelease:
		    i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);
		    if (but_stat == i && but_stat >= 0)
		    {
			// A button has been pressed
			if (but_stat == 8) 
			{
			    sprintf (exec, "xterm -e tail -f -n %d %s %s %s &\n", taillines, filename1, filename2, xerr);
			    system (exec); // start logprog 
			    printf ("\n%s", exec);
			}
			else if (but_stat == 9)
			    scrollit=1-scrollit;
			else
			    index = but_stat;
	
			// Clear counter number zone
			copyXPMArea(4, 84, 13, 10, 46, 21);
    
			// Display counter number
			BlitNum (logged[index], 52, 21);
	
			copyXPMArea(4, 84, 55, 10, 4, 35);
			BlitString(labels+(10*index), 5,35);
			DisplayLabel (labels+(10*index));
		    }
		but_stat = -1;
		break;
	    }
	}
	
	update ();
	if (scrollit)
	{
	    DisplayScroll (newstr, pos);
	    pos++;
	    if (pos>=strlen(newstr)+9)
		pos = pos-strlen(newstr)-8;
	}
	else    
	    DisplayScroll (newstr, pos);
	BlitNum (min(logged[index],99), 52, 21);
	for (i=0; i<8; i++)
	{
	    if (counters[i]==0)
		continue;
	    else if (counters[i]==1)
		clr_led(i);
	    counters[i]--;  
	}
	if (maincounter > 0)
	{
	    copyXPMArea(74, 33, 55, 4, 4,  13);
	    maincounter--;
	}   
	else    
	    copyXPMArea(74, 14, 55, 4, 4,  13);
	usleep(60000/5*scroll);
    }

}

void DisplayScroll (char *label, int position)
{
    char label2 [256];
    char *label1 = malloc (strlen(label)+9);
    sprintf (label1, "         %s", label);
    strncpy (label2, label1+position,min(strlen(label1)-position+1,255));
    // Clear display zones
    copyXPMArea(4, 84, 55, 10, 4, 49);

    BlitString (label2, 4, 49/*35*/);
    free (label1);
}

// Blits a string at given co-ordinates
void BlitString(char *name, int x, int y)
{
    int	    i;
    int	    c;
    int	    k;

    k = x;
    for (i=0; name[i]!=0 && name[i]!='\n' && i<9; i++)
    {

    c = toupper(name[i]); 
    if (c=='=')
	c=':';
    if (c >= 'A' && c <= 'Z' && c!=0)
    {   // its a letter
	c -= 'A';
	copyXPMArea(c * 6, 74, 6, 8, k, y);
	k += 6;
    }
    else if (c>='0' && c<='=')
    {   // its a number or symbol
	c -= '0';
	copyXPMArea(c * 6, 64, 6, 8, k, y);
	k += 6;
    }
    else 
    {   
	copyXPMArea(75, 13, 6, 8, k, y);
	k += 6;
    }   
    }

}


// Blits number to give coordinates.. nine 0's, right justified

void BlitNum(int num, int x, int y)
{
    char buf[1024];
    int newx=x;

    if ( num > 9 )
	newx -= 6;
    if ( num > 99 )
	num=99;//newx -= 6;
/*  if ( num > 999 ) newx -= 6;
    if ( num > 9999 ) newx -= 6; 
    if ( num > 99999 ) newx -= 6;
    if ( num > 999999 ) newx -= 6;
    if ( num > 9999999 ) newx -= 6; 
    if ( num > 99999999 ) newx -= 6;*/
 
    sprintf(buf, "%d", min(99,num));

    BlitString(buf, newx, y);
}
    
// Split a label and display it

void DisplayLabel (char *label)
{

    char *label2;

    // Clear display zones
    copyXPMArea(4, 84, 55, 10, 4, 35);

    if (label != NULL)
    {
	label2=label;
	BlitString (label2, 4, 35);
    }
 }

