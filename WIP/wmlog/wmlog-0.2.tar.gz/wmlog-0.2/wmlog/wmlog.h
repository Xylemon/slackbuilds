#define file1str "/var/log/messages" 
#define file2str "/var/log/warn" 
#define file3str ".xsession-errors" 
