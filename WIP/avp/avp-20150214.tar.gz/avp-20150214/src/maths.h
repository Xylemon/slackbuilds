#ifndef MATHS_H
#define MATHS_H

void SetSeededFastRandom(int seed);
int SeededFastRandom(void);

#endif
