extern void CreateRubberDuckBot(void);
extern void CreateRubberDuck(VECTORCH *positionPtr);
extern void CreateRubberDucks(void);
extern void RubberDuckBehaviour(STRATEGYBLOCK *sbPtr);

extern void CreateFlamingDebris(VECTORCH *positionPtr, VECTORCH *dirPtr);
