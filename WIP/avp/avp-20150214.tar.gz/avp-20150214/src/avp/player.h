#ifndef PLAYER_H
#define PLAYER_H

void DeInitialisePlayer(void);
void ChangeToMarine();
void ChangeToAlien();
void ChangeToPredator();

#endif
