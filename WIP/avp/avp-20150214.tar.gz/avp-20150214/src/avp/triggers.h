extern void OperateObjectInLineOfSight(void);
extern BOOL AnythingInMyModule(MODULE* my_mod);
