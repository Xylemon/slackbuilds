/*
	
	projtext.h

	Created 12 Nov 97 by DHM: Project specific text type

*/

#ifndef _projtext
#define _projtext 1

#ifdef __cplusplus
	extern "C" {
#endif

/* Version settings *****************************************************/

/* Constants  ***********************************************************/

/* Macros ***************************************************************/

/* Type definitions *****************************************************/

	typedef char ProjChar;

/* Exported globals *****************************************************/

/* Function prototypes **************************************************/



/* End of the header ****************************************************/


#ifdef __cplusplus
	};
#endif

#endif
