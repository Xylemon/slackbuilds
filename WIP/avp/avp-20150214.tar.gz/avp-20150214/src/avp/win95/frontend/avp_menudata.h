#ifndef AVP_MENUDATA_H
#define AVP_MENUDATA_H

void MakeConnectionSelectMenu();

#endif
