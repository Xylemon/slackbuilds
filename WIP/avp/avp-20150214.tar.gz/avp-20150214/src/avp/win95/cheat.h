extern void HandleCheatModes(void);
extern void GiveAllWeaponsCheat(void);
