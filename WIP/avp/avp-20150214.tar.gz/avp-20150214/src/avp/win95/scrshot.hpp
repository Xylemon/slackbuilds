#ifdef __cplusplus
extern "C" {
#endif

extern void ScreenShot();
extern void HandleScreenShot();

#ifdef __cplusplus

};
#endif
