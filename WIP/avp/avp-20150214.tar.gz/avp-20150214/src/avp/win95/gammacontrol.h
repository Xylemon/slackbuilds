#ifndef _included_GammaControl_h_
#define _included_GammaControl_h_ 1

extern void InitialiseGammaSettings(int gamma);
extern void UpdateGammaSettings(void);
extern int RequestedGammaSetting;


#endif
