
extern void NearAlienBehaviour(STRATEGYBLOCK *sbPtr);
