#ifndef GAME_H
#define GAME_H

void TimeStampedMessage(char *stringPtr);

#endif
