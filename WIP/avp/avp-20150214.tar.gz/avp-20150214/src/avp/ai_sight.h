#ifndef AI_SIGHT_H
#define AI_SIGHT_H

#define NPC_MAX_VIEWRANGE (50000)

extern int NPCCanSeeTarget(STRATEGYBLOCK *sbptr, STRATEGYBLOCK *target, int viewRange);

#endif
