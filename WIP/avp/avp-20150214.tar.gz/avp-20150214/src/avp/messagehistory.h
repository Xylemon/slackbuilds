#ifndef MESSAGEHISTORY_H
#define MESSAGEHISTORY_H

void MessageHistory_DisplayPrevious(void);
void MessageHistory_Initialise(void);
void MessageHistory_Maintain(void);

#endif
