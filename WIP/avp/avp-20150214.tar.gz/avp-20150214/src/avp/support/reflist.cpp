/*******************************************************************
 *
 *    DESCRIPTION: 	reflist.cpp
 *
 *    AUTHOR: David Malcolm
 *
 *    HISTORY:  Created 28/1/98
 *
 *******************************************************************/

/* Includes ********************************************************/
#include "3dc.h"
#include "reflist.hpp"

/* Exported globals ************************************************/

	char const* reflist_fail_destructor = "Failure in RefList destructor\n";
