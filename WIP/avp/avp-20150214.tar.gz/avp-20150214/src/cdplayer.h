#ifndef CDPLAYER_H
#define CDPLAYER_H

void CDDA_Start();
void CDDA_Stop();
void CDDA_End();
void CheckCDVolume();

#endif
