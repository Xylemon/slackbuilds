# wmgotchi
![alt tag](http://euksy.oldtimes-software.com/files/UNIX/wmgotchi0.gif)
![alt tag](http://euksy.oldtimes-software.com/files/UNIX/wmgotchi1.gif)
![alt tag](http://euksy.oldtimes-software.com/files/UNIX/wmgotchi2.gif)
![alt tag](http://euksy.oldtimes-software.com/files/UNIX/wmgotchi3.gif)

wmgotchi is a dockapp written in C.
Based on a popular japanese toy, here comes a dockapp.

This was written as a sort of practice regarding dockapps! 
Feel free to expand upon it and send pull requests.

#Requirements
GTK+2 with GDK

#Compiling
make

./wmgotchi

#Features
![alt tag](http://euksy.oldtimes-software.com/files/UNIX/wmgotchi_overview.gif)

wmgotchi's can live up to 5 gotchi years! Watch it hatch and see it become a baby, child, teen and adult.
Watch out for its needs, like e.g. hunger. Don't let it become too bored either! Keep it clean and healthy.
No one likes dead gotchis.

#To-Do
- Finishing the gfx for age 3 and 4
- creating the info screen (right now dialog output will do)
- support custom skins via parameter 
- balance the difficulty, adjust values

#Notes
This was written on Slackware64 with WindowMaker in mind.
