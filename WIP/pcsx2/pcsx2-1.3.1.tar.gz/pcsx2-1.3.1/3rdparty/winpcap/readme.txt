Winpcap is version 4.1.2 downloaded from
https://www.winpcap.org/install/bin/WpdPack_4_1_2.zip
Just the /include and /lib directories are included to keep the size small.