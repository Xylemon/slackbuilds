
// Pcsx2-specific Feature: Precompiled Header support!

#ifndef _PTHREAD_W32_PCH_
#define _PTHREAD_W32_PCH_

#include <errno.h>
#include <limits.h>

#include "pthread.h"
#include "implement.h"

#endif