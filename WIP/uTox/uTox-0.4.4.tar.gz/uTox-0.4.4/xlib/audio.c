
void audio_detect(void)
{
}

_Bool audio_init(void *handle)
{
    return 0;
}

_Bool audio_close(void *handle)
{
    return 0;
}

_Bool audio_frame(int16_t *buffer)
{
    return 0;
}
